#ifndef WORKSHOPTYPE_H
#define WORKSHOPTYPE_H

enum class WorkshopType{
    SERVICE,
    REPAIRS,
    BOTH
};

#endif // WORKSHOPTYPE_H
